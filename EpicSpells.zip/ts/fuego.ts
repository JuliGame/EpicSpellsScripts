import {Particle, Pentagrama, Sound, SpellLogic} from "./j2ts/jdk8-types";

function getJSSpell() {

    let spell = new SpellLogic("test");

    spell.setOnCast( (event) => {
        event.getEndCastLocation().getWorld().spawnParticle(Particle.FLAME, event.getEndCastLocation(), 0);
        event.getCaster().playSound(event.getCaster().getLocation(), Sound.BLOCK_LAVA_EXTINGUISH, 0.4, 2);

        let pentagrama = Pentagrama.get(0, 0, 2)

        return true;
    });

    return spell;
}